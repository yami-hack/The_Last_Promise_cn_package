/*
 * link_func.h
 *
 *  Created on: 2015年4月19日
 *      Author: yami
 */


/**
 * @file		link_func.h
 * @author		yami
 * @date		2015-04-19 14:14:23
 * @brief
 * 链接的函数
 */


#ifndef SRC_LINK_FUNC_H_
#define SRC_LINK_FUNC_H_


extern	void *sub_80BFC54(void*,u32,void*);


#endif /* SRC_LINK_FUNC_H_ */
