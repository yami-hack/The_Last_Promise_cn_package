/*
 * link.c
 *
 *  Created on: 2015年4月19日
 *      Author: yami
 */


/**
 * @file		link.c
 * @author		yami
 * @date		2015-04-19 16:01:43
 * @brief
 * 链接一些ROM内部的函数不出错
 */
#include "types.h"

void* sub_80BFC54(void*a0){
	return a0;
}

void SECTION(".link")	text_decode(void*a0,void*a1)
{

}
