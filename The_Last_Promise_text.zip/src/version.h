/*
 * version.h
 *
 *  Created on: 2015年4月19日
 *      Author: yami
 */

/**
 * @file		version.h
 * @date		2015-04-19 14:25:38
 * @author		yami
 * @brief
 * 这是版本定义
 */

#ifndef SRC_VERSION_H_
#define SRC_VERSION_H_


#define 	TLP
#define		TLP_CN
#define		TLP_CN_V1


#endif /* SRC_VERSION_H_ */
